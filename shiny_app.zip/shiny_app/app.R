################################################################################
# Title: app.R

# Description:
# Generates the web-based SeweRx R Shiny app. Provides user instructions and 
# allows them to input their own facility data including daily flow or design
# capacity and sewershed population size. Runs PharmFlush model to predict the
# mass loads for the specific water resource recovery facility. Allows the user
# to download PharmUse database and PharmFlush output as csv files.

################################################################################

# import libraries
library(shiny)
library(bslib)
library(DT)
library(tidyverse)
library(RColorBrewer)
library(shinycssloaders) 

# load necessary functions
source("pharmflush_function.R")

################################################################################
# user interface
################################################################################
ui <- fluidPage(
  theme = bs_theme(version = 5, bootswatch = "minty"),
  
  titlePanel("SeweRx"),
  
  sidebarLayout(
    sidebarPanel(
      accordion(
        id = "help_section",
        accordion_panel("What is the SeweRx app?",
                        p("SeweRx consists of two modules, PharmUse and PharmFlush, and continues to grow every day."),
                        p("PharmUse is a database containing data on pharmaceutical consumption, excretion, fate and transport properties, and toxicity for 313 commonly-prescribed pharmaceuticals."),
                        p("PharmFlush is a predictive modeling tool trained on PharmUse data and built into SeweRx. PharmFlush estimates national baseline pharmaceutical mass loads in wastewater influent based on user-defined flow and population parameters."),
                        p("To use SeweRx, enter your WRRF's flow capacity and sewershed size, then click 'Run Model'. This will generate the predicted national baseline pharmaceutical loads at the scale of your WRRF's flows and population."),
                        p("SeweRx assists with treatment priortization and selection of indicator compounds for process monitoring. You can do this by comparing your WRRF's pharmaceutical mass loads against the national average predicted by PharmFlush. We hope this tool will be helpful as more water reuse regulations are passed."),
                        p("For assistance, contact Vanessa Maybruck at vanessa.maybruck@colorado.edu.")
        ),
        accordion_panel("Inputs Explained",
                        tags$ul(
                          tags$li(strong("Daily Flow or Flow Capacity of WRRF (L/day):"), "Typical flow associated with your WRRF or design capacity of your WRRF. Use typical flows for the best results. The default value (34,225,766 L/d) is the flow capacity calculated from the average daily wastewater volume produced per individual in the U.S. (310.404 L/capita/day) and the average sewershed population from the validation set used for PharmFlush (110,262 people)."),
                          tags$li(strong("Sewershed Size:"), "Total number of people contributing to flows in your WRRF. The default value is the average sewershed size in the validation set used in PharmFlush (110,262 people).")
                        )
        )
      ),
      br(),
      downloadButton("download_file", "Download PharmUse data"),
      hr(),
      
      numericInput("flow_capacity", "Flow Capacity (L/day)", value = 34225766) %>%
        tooltip("Typical flow associated with your WRRF or design capacity of your WRRF. Use typical flows for the best results. The default value (34,225,766 L/d) is the flow capacity calculated from the average daily wastewater volume produced per individual in the U.S. (310.404 L/capita/day) and the average sewershed population from the validation set used for PharmFlush (110,262 people).", placement = "right"),
      
      numericInput("population_served", "Sewershed Size", value = 110262) %>%
        tooltip("Total number of people contributing to flows in your WRRF. The default value is the average sewershed size in the validation set used in PharmFlush (110,262 people).", placement = "right"),
      
      actionButton("run_model", "Run Model", class = "btn-primary", width = "100%"),
      br(), br(),
      downloadButton("download_full_data", "Download PharmFlush output")
    ),
    
    mainPanel(
      tabsetPanel(
        tabPanel("National Baseline Mass Loads", 
                 br(),
                 # We wrap the output in withSpinner
                 withSpinner(
                   DT::dataTableOutput("average_profile"),
                   type = 6,    # You can choose types 1-8
                   color = "#78c2ad" # Matches the Minty theme green
                 )
        )
      )
    )
  )
)

################################################################################
# server
################################################################################
server <- function(input, output, session) {
  
  model_results_reactive <- reactiveVal(NULL)
  
  # 1. Trigger the model calculation
  observeEvent(input$run_model, {
    id <- showNotification("Calculating...", duration = NULL, closeButton = FALSE)
    on.exit(removeNotification(id), add = TRUE)
    
    results <- pharmflush_model(
      flow_capacity = input$flow_capacity,
      population_served = input$population_served
    )
    
    model_results_reactive(results)
  })
  
  processed_data <- reactive({
    res <- model_results_reactive()
    req(res, res$average_profile)
    
    df <- as.data.frame(res$average_profile)
    
    df %>%
      dplyr::rename(
        `Predicted Mass Load (ug/capita/day)` = Average_Predicted_Mass_Load,
        Pharmaceutical = Drug
      ) %>%
      mutate(`Predicted Mass Load (ug/capita/day)` = as.numeric(`Predicted Mass Load (ug/capita/day)`)) %>%
      select(Pharmaceutical, `Predicted Mass Load (ug/capita/day)`)
  })
  
  output$average_profile <- DT::renderDataTable({
    df <- processed_data() 
    
    DT::datatable(
      df,
      rownames = FALSE,
      options = list(
        pageLength = 10,
        autoWidth = TRUE,
        scrollX = TRUE
      )
    ) %>%
      DT::formatRound(columns = 'Predicted Mass Load (ug/capita/day)', digits = 2)
  })
  
  output$download_full_data <- downloadHandler(
    filename = function() { paste0("pharmflush_output_", Sys.Date(), ".csv") },
    content = function(file) {
      write.csv(processed_data(), file, row.names = FALSE)
    }
  )
  
  output$download_file <- downloadHandler(
    filename = function() { "pharmuse.csv" },
    content = function(file) { file.copy("pharmuse.csv", file) }
  )
}

# run the app
shinyApp(ui = ui, server = server)